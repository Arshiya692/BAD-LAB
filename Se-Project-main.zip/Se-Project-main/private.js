const JWT = '33irbr9r998egghreubt4tb9ebfuisdufui34';
const MONGOURL ='mongodb+srv://iit2021182:ramramram@cluster0.d0oqtnf.mongodb.net/?retryWrites=true&w=majority';

    
    
exports.JWT = JWT;
exports.MONGOURL = MONGOURL;