const express = require("express");
const app = express();
const path = require('path');
const { verifyUser } = require("../middlewars/verifyUser");

let x = path.resolve() + '/views/';

app.get('/home/:username', verifyUser, (req, res) => {
    res.sendFile(x + 'home.html');
})

module.exports = app;