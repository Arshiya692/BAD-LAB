const express = require("express");
const app = express();
const path = require('path')
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const saltRounds = 10;
const { JWT } = require('../private.js');
const Users = require("../model/users.js");
let x = path.resolve() + '/views/';


app.get('/register', (req, res) => {
    res.sendFile(x + '/signup.html');
})

app.post('/register', async (req, res) => {
    const { password, ...otherdata } = req.body;
    let data = await Users.collection.find({
        $or: [
            otherdata
        ]
    })

    if (data) {
        res.send({ "error": "User already exist", "data": req.body });
    }
    else {
        bcrypt.hash(myPlaintextPassword, saltRounds, function (err, hash) {
            password = hash;
        });
        let newUser = {
            password, ...otherdata
        }
        newUser = new Users(newUser);
        newUser = await newUser.save();
        res.send({ "error": "", "data": {} });
    }
})


app.get('/login', (req, res) => {
    res.sendFile(path.resolve() + '/views/login.html');
})

app.post('/login', async (req, res) => {
    let user = req.body;
    let data = await Users.find({ username: req.body.username });
    if (!data) {
        res.json({ "error": "Wrong Username or password", "data": null });
    }
    else {
        bcrypt.compare(req.body.password, data.password, function (err, result) {
            if (result) {
                let token = jwt.sign(data, JWT);
                res.cookie("access_token", token).json({ "error": null, "data": { "username": data.username } });
            }
            else {
                res.json({ "error": "Wrong Username or password", "data": null });
            }
        });
    }
})


module.exports = app;